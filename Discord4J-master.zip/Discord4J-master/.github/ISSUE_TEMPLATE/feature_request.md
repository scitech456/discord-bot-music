---
name: Feature Request
about: Suggest an idea for this project

---

<!--
YOUR ISSUE MAY BE CLOSED IF YOU DO NOT FOLLOW THIS TEMPLATE

Consider searching for similar issues before submitting yours:
https://github.com/Discord4J/Discord4J/issues?q=is%3Aissue+label%3A%22feature+request%22
-->

**Feature Description:** <!-- A description of the feature you are requesting. -->

**Justification:** <!-- Justification for the feature you are requesting. -->